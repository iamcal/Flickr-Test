package Flickr::Test;

use vars qw(@ISA @EXPORT $PhpDir);
use Exporter;
@ISA = ('Exporter');
@EXPORT = qw(&runtests);

our $VERSION = 1.00_01;

use Test::Harness;
use Flickr::Test::Straps;

sub runtests {

	#
	# need to find out where we keep our PHP files
	#

	$Flickr::Test::PhpDir = '';

	for my $path (@INC){
		if (-e "$path/Flickr/Test/Straps.php"){
			$Flickr::Test::PhpDir = $path;
		}
	}


	#
	# todo: make this configurable?
	#

	$Test::Harness::verbose=1;

	bless $Test::Harness::Strap, 'Flickr::Test::Straps';

	if (@ARGV){
		Test::Harness::runtests @ARGV;
	}else{
		@tests = (glob("t/*.t"), glob("t/*/*.t"));
		Test::Harness::runtests @tests;
	}
}

1;
